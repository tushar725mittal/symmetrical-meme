#define NUMBER 257
#define EOL 258
