#include <stdio.h>

int print()
{
    printf("");
}

int main()
{
    int a, b;
    int c = a + b;
    printf(a, b, c);

    return 0;
}